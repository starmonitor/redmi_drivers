﻿All notable changes to this project will be documented in this file.

##  [02.00.00.1097] - 2020-10-20
### Fixed
-    "Fixed QoS high resolution timer disabling for large timeout values."
### Modified
-    "Removed legacy interrupt support, simplified project"
### Added
-    "Added Abort completion verification  for 2.0 HW"

##  [02.00.00.1060] - 2020-09-03
### Fixed
-    "Added QoS and ISR timer synchronization."

##  [02.00.00.1050] - 2020-08-20
### Fixed
-    "Secure memory map/unmap flow for invalid request object in map cncl evn"

##  [02.00.00.1047] - 2020-07-28
### Fixed
-    "Security Review - Permission fixes - added missing permission"

##  [02.00.00.1027] - 2020-07-24
### Fixed
-    "Block legacy DDI when using GNA devices above 1.0"

##  [02.00.00.1010] - 2020-07-14
### Fixed
-    "Remove debug information due to security review"
-    "Security Review - Permission fixes"

##  [02.00.00.0984] - 2020-06-30
### Fixed
-    "Security Review - Code review fixes"

##  [02.00.00.0967] - 2020-06-15
### Added
-    "TGL QoS Implementation"
-    "Power gating override for JSL workaround"

### Fixed
-    "Fixes, including partial cancel IO support to handle unexpected application termination"

##  [02.00.00.0925] - 2020-05-26
### Added
-    "Model error reporting"
-    "DDI: Notify removal"
-    "20h1 WDK support"

### Fixed
-    "Performance instrumentation fix"


### BKMs/Notes

1.  Hardware Compatibility

    The GNA CPU offload and acceleration capability is supported by the following Intel platforms in the post-Si:
    *    Gemini Lake
    *    Cannon Lake
    *    Ice Lake
    *    Jasper Lake+
    *    Rocket Lake
    *    Tiger Lake


2.  Supported Operating Systems

    Details of the support for Microsoft* OSes:
    *    Windows* 10 Threshold 1
    *    Windows* 10 Threshold 2
    *    Windows* 10 Red Stone 1
    *    Windows* 10 Red Stone 2
    *    Windows* 10 Red Stone 3
    *    Windows* 10 Red Stone 4
    *    Windows* 10 Red Stone 5
    *    Windows* 10 Red Stone 6
    *    Windows* 10 2019H1
    *    Windows* 10 2019H2
    *    Windows* 10 2020H1